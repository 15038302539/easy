$(function(){
	$('#d1').click(function(){
		//this.innerHTML = 'hello perl';
		$(this).css('font-size','80px');
	});
});

$(function(){
	$('#d1').click(function(){
		
	});
});


