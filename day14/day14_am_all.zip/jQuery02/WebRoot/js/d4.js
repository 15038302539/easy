window.onload = function(){
	var obj = document.getElementById('d1');
	obj.onclick=function(){
	this.innerHTML = 'hello java';
	};
};

